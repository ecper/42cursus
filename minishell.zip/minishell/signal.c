/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signal.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hauchida <hauchida@student.42tokyo.jp>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/07 17:28:01 by hauchida          #+#    #+#             */
/*   Updated: 2024/12/07 20:03:06 by hauchida         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	signal_handler_test(int sig, siginfo_t *info, void *context)
{
	printf("getsig: %d\n", sig);
	// exit(0);
	return ;
}

int	start_signal(void)
{
	struct sigaction s_sigaction;

	s_sigaction.sa_flags = SA_SIGINFO;
	s_sigaction.sa_sigaction = &signal_handler_test;
	sigemptyset(&s_sigaction.sa_mask);
	// sigaddset(&s_sigaction.sa_mask, SIGINT);
	if (sigaction(SIGINT, &s_sigaction, NULL) < 0)
		exit(EXIT_FAILURE);
	while (1)
		pause();
}